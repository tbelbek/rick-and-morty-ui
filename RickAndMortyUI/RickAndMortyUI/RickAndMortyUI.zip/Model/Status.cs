﻿namespace RickAndMortyUI.Model
{
    public enum Status { Alive, Dead, Unknown }
}